----------------------------
--[[ Strings in use:
----------------------------

Import
Your gamepad bindings for %s have been saved.
Your gamepad bindings have been saved.

---------------------------]]